#include <unistd.h>

int	main(int argc, char **argv)
{
	int	i;
	int	start;
	int	end;

	// Se il numero di argomenti è diverso da 1 (quindi argc != 2), 
	// il programma salta direttamente al write("\n") finale.
	if (argc == 2)
	{
		i = 0;
		// 1. Trova la fine della stringa (la lunghezza)
		while (argv[1][i])
			i++;
		
		// Imposta l'indice 'end' sull'ultimo carattere effettivo della stringa
		end = i - 1;
		
		// 2. Ciclo principale che cammina all'indietro
		while (end >= 0)
		{
			// Fissa l'inizio temporaneo della parola sulla fine
			start = end;
			
			// Cammina all'indietro finché trova lettere (si ferma allo spazio o a inizio stringa)
			while (start >= 0 && argv[1][start] != ' ' && argv[1][start] != '\t')
				start--;
			
			// 3. Stampa la parola appena isolata (da start + 1 fino a end)
			i = start + 1;
			while (i <= end)
			{
				write(1, &argv[1][i], 1);
				i++;
			}
			
			// 4. Gestione dello spazio di separazione
			// Se start è maggiore o uguale a 0, significa che ci si è fermati su uno spazio,
			// quindi ci sono ancora altre parole da stampare prima di questa.
			if (start >= 0)
				write(1, " ", 1);
			
			// Sposta il puntatore 'end' prima dello spazio, pronti per la parola precedente
			end = start - 1;
		}
	}
	// Stampa il newline finale obbligatorio
	write(1, "\n", 1);
	return (0);
}