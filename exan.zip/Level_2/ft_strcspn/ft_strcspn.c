/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcspn.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: enucci <enucci@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/01 02:10:55 by columbux          #+#    #+#             */
/*   Updated: 2026/06/07 14:08:50 by enucci           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* #include <stdlib.h>
#include <stdio.h> */

size_t  ft_strcspn(const char *s, const char *reject)
{
    size_t  i;
    size_t  j;

    i = 0;
    while (s[i] != '\0')
    {
        j = 0;
        // Per ogni carattere di 's', scorriamo tutta la lista nera 'reject'
        while (reject[j] != '\0')
        {
            // Se troviamo una corrispondenza, CI FERMIAMO!
            if (s[i] == reject[j])
                return (i);
            j++;
        }
        // Il carattere s[i] non era in reject, quindi andiamo avanti
        i++;
    }
    // Se arriviamo alla fine senza aver trovato nulla, 
    // la lunghezza coincide con tutta la stringa 's'
    return (i);
}

/* int	main(int argc, char **argv)
{
	if (argc == 3)
		printf("%lu", ft_strcspn(argv[1], argv[2]));
	printf("\n");
	return (0);
}
 */