#include <unistd.h>

int	main(int argc, char **argv)
{
	int	i;
	int	j;
	int	k;
	int	drawn;

	
	if (argc == 3)
	{
		i = 0;
		while (argv[1][i])
		{
			drawn = 0;

			j = 0;
			while (j < i)
			{
				if (argv[1][j] == argv[1][i])
					drawn = 1;
				j++;
			} //controllo che non e un carattere gia stampato


			if (drawn == 0)
			{
				k = 0;

				while (argv[2][k])
				{
					if (argv[1][i] == argv[2][k])
					{
						write(1, &argv[1][i], 1);
						break;
					}
					k++;
				}
			}
			i++;
		}
	}
	write(1, "\n", 1);
	return (0);
}





#include <unistd.h>

int main(int argc, char **argv)
{
    int i;
    int lookup[256] = {0};


    if (argc == 3)
    {	
        i = 0;
        while (argv[2][i] != '\0')
        {
            lookup[(unsigned char)argv[2][i]] = 1;
            i++;
        }

        i = 0;
        while (argv[1][i] != '\0')
        {
            if (lookup[(unsigned char)argv[1][i]] == 1)
            {
                write(1, &argv[1][i], 1);
                lookup[(unsigned char)argv[1][i]] = 2;
            }
            i++;
        }
    }

    write(1, "\n", 1);
    return (0);
}
